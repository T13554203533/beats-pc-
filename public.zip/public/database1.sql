set name utf8;
drop database if exists beats;
create database beats charset=utf8;
use beats;

create table bs_product_detail(
	id int(10) primary key auto_increment,
	pid int(10) unique,
	title varchar(100),
	subtitle varchar(100),
	pirce  decimal(7,2),
	salenum varchar(10),
	evaluate varchar(10),
	integral varchar(10),
	pricethree varchar(20),
	threestages varchar(20),
	pricesix varchar(20),
	sixstages varchar(20),
	pricetwelve varchar(10),
 	twelvestages varchar(20)	
);
insert into bs_product_detail values (null,1,'��6����Ϣ��Beats Pro ¼��ʦרҵ��ͷ��ʽ��������','6����Ϣ ȫ������ Ϊ¼���Ҷ���','3061','14','109','306','1020.33','��3��','510.16','��6��','274.21','��12��');
insert into bs_product_detail values (null,9,'��������Ϣ��Beats Solo3 Wireless �ر�� ����90�����������','6����Ϣ ����90��������','2268','963','2102','220','736.33','��3��','368.16','��6��','184.08','��12��');
insert into bs_product_detail values (null,6,'��12����Ϣ��Beats Studio 3 Wireless���߽����������ͷ��ʽ','ȫ������ 12����Ϣ �������� �ܾ�����','2863','515','7771','278','929.66','��3��','464.83','��6��','232.14','��12��');
insert into bs_product_detail values (null,8,'��6����Ϣ��Beats Solo3 Wireless ͷ��ʽ����������������','6����Ϣ Ϊ�������� Ϊ�������','2268','745','9253','220','736.33','��3��','368.16','��6��','184.08','��12��');

create table bs_detail_color(
	id int(10) primary key auto_increment,
	pid varchar(10),
	pcolor varchar(200) ,
	cname varchar(10) 	 
);

insert into bs_detail_color values (null,1,'http://127.0.0.1:3000/pro_color/1_color_1.jpg','����ɫ');
insert into bs_detail_color values (null,6,'http://127.0.0.1:3000/pro_color/6_color_1.jpg','��ɫ');
insert into bs_detail_color values (null,6,'http://127.0.0.1:3000/pro_color/6_color_2.jpg','��ɫ');
insert into bs_detail_color values (null,6,'http://127.0.0.1:3000/pro_color/6_color_3.jpg','��Ӱ��');
insert into bs_detail_color values (null,6,'http://127.0.0.1:3000/pro_color/6_color_4.jpg','��ɫ');
insert into bs_detail_color values (null,6,'http://127.0.0.1:3000/pro_color/6_color_5.jpg','��ɫ');
insert into bs_detail_color values (null,6,'http://127.0.0.1:3000/pro_color/6_color_6.jpg','����ں�');
insert into bs_detail_color values (null,6,'http://127.0.0.1:3000/pro_color/6_color_7.jpg','��ҹ��');
insert into bs_detail_color values (null,6,'http://127.0.0.1:3000/pro_color/6_color_8.jpg','ˮ����');
insert into bs_detail_color values (null,6,'http://127.0.0.1:3000/pro_color/6_color_9.jpg','��ɫ');
insert into bs_detail_color values (null,6,'http://127.0.0.1:3000/pro_color/6_color_10.jpg','ɳĮ��');
insert into bs_detail_color values (null,8,'http://127.0.0.1:3000/pro_color/8_color_1.jpg','��ɫ');
insert into bs_detail_color values (null,8,'http://127.0.0.1:3000/pro_color/8_color_2.jpg','����ɫ');
insert into bs_detail_color values (null,8,'http://127.0.0.1:3000/pro_color/8_color_3.jpg','��ɫ');
insert into bs_detail_color values (null,8,'http://127.0.0.1:3000/pro_color/8_color_4.jpg','����ɫ');
insert into bs_detail_color values (null,8,'http://127.0.0.1:3000/pro_color/8_color_5.jpg','��ɫ');
insert into bs_detail_color values (null,8,'http://127.0.0.1:3000/pro_color/8_color_6.jpg','ש��ɫ');
insert into bs_detail_color values (null,8,'http://127.0.0.1:3000/pro_color/8_color_7.jpg','���');
insert into bs_detail_color values (null,8,'http://127.0.0.1:3000/pro_color/8_color_8.jpg','�ǹ���');
insert into bs_detail_color values (null,8,'http://127.0.0.1:3000/pro_color/8_color_9.jpg','˿�н�');
insert into bs_detail_color values (null,8,'http://127.0.0.1:3000/pro_color/8_color_10.jpg','˿����');
insert into bs_detail_color values (null,9,'http://127.0.0.1:3000/pro_color/9_color_1.jpg','����90�ܼ����');

create table bs_detail_carousel(
	id int(10) primary key auto_increment,
	pid varchar(10),
	picsm varchar(200), 
	picmd varchar(200),
	piclg varchar(200)
);

insert into bs_detail_carousel values (null,1,'http://127.0.0.1:3000/pro_carou/1_sm_1.jpg','http://127.0.0.1:3000/pro_carou/1_md_1.jpg','http://127.0.0.1:3000/pro_carou/1_lg_1.jpg');
insert into bs_detail_carousel values (null,1,'http://127.0.0.1:3000/pro_carou/1_sm_2.jpg','http://127.0.0.1:3000/pro_carou/1_md_2.jpg','http://127.0.0.1:3000/pro_carou/1_lg_2.jpg');
insert into bs_detail_carousel values (null,1,'http://127.0.0.1:3000/pro_carou/1_sm_3.jpg','http://127.0.0.1:3000/pro_carou/1_md_3.jpg','http://127.0.0.1:3000/pro_carou/1_lg_3.jpg');
insert into bs_detail_carousel values (null,1,'http://127.0.0.1:3000/pro_carou/1_sm_4.jpg','http://127.0.0.1:3000/pro_carou/1_md_4.jpg','http://127.0.0.1:3000/pro_carou/1_lg_4.jpg');
insert into bs_detail_carousel values (null,1,'http://127.0.0.1:3000/pro_carou/1_sm_5.jpg','http://127.0.0.1:3000/pro_carou/1_md_5.jpg','http://127.0.0.1:3000/pro_carou/1_lg_5.jpg');
insert into bs_detail_carousel values (null,1,'http://127.0.0.1:3000/pro_carou/1_sm_6.jpg','http://127.0.0.1:3000/pro_carou/1_md_6.jpg','http://127.0.0.1:3000/pro_carou/1_lg_6.jpg');
insert into bs_detail_carousel values (null,6,'http://127.0.0.1:3000/pro_carou/6_sm_1.jpg','http://127.0.0.1:3000/pro_carou/6_md_1.jpg','http://127.0.0.1:3000/pro_carou/6_lg_1.jpg');
insert into bs_detail_carousel values (null,6,'http://127.0.0.1:3000/pro_carou/6_sm_2.jpg','http://127.0.0.1:3000/pro_carou/6_md_2.jpg','http://127.0.0.1:3000/pro_carou/6_lg_2.jpg');
insert into bs_detail_carousel values (null,6,'http://127.0.0.1:3000/pro_carou/6_sm_3.jpg','http://127.0.0.1:3000/pro_carou/6_md_3.jpg','http://127.0.0.1:3000/pro_carou/6_lg_3.jpg');
insert into bs_detail_carousel values (null,6,'http://127.0.0.1:3000/pro_carou/6_sm_4.jpg','http://127.0.0.1:3000/pro_carou/6_md_4.jpg','http://127.0.0.1:3000/pro_carou/6_lg_4.jpg');
insert into bs_detail_carousel values (null,6,'http://127.0.0.1:3000/pro_carou/6_sm_5.jpg','http://127.0.0.1:3000/pro_carou/6_md_5.jpg','http://127.0.0.1:3000/pro_carou/6_lg_5.jpg');

insert into bs_detail_carousel values (null,8,'http://127.0.0.1:3000/pro_carou/8_sm_1.jpg','http://127.0.0.1:3000/pro_carou/8_md_1.jpg','http://127.0.0.1:3000/pro_carou/8_lg_1.jpg');
insert into bs_detail_carousel values (null,8,'http://127.0.0.1:3000/pro_carou/8_sm_2.jpg','http://127.0.0.1:3000/pro_carou/8_md_2.jpg','http://127.0.0.1:3000/pro_carou/8_lg_2.jpg');
insert into bs_detail_carousel values (null,8,'http://127.0.0.1:3000/pro_carou/8_sm_3.jpg','http://127.0.0.1:3000/pro_carou/8_md_3.jpg','http://127.0.0.1:3000/pro_carou/8_lg_3.jpg');
insert into bs_detail_carousel values (null,8,'http://127.0.0.1:3000/pro_carou/8_sm_4.jpg','http://127.0.0.1:3000/pro_carou/8_md_4.jpg','http://127.0.0.1:3000/pro_carou/8_lg_4.jpg');
insert into bs_detail_carousel values (null,8,'http://127.0.0.1:3000/pro_carou/8_sm_5.jpg','http://127.0.0.1:3000/pro_carou/8_md_5.jpg','http://127.0.0.1:3000/pro_carou/8_lg_5.jpg');

insert into bs_detail_carousel values (null,9,'http://127.0.0.1:3000/pro_carou/9_sm_1.jpg','http://127.0.0.1:3000/pro_carou/9_md_1.jpg','http://127.0.0.1:3000/pro_carou/9_lg_1.jpg');
insert into bs_detail_carousel values (null,9,'http://127.0.0.1:3000/pro_carou/9_sm_2.jpg','http://127.0.0.1:3000/pro_carou/9_md_2.jpg','http://127.0.0.1:3000/pro_carou/9_lg_2.jpg');
insert into bs_detail_carousel values (null,9,'http://127.0.0.1:3000/pro_carou/9_sm_3.jpg','http://127.0.0.1:3000/pro_carou/9_md_3.jpg','http://127.0.0.1:3000/pro_carou/9_lg_3.jpg');
insert into bs_detail_carousel values (null,9,'http://127.0.0.1:3000/pro_carou/9_sm_4.jpg','http://127.0.0.1:3000/pro_carou/9_md_4.jpg','http://127.0.0.1:3000/pro_carou/9_lg_4.jpg');
insert into bs_detail_carousel values (null,9,'http://127.0.0.1:3000/pro_carou/9_sm_5.jpg','http://127.0.0.1:3000/pro_carou/9_md_5.jpg','http://127.0.0.1:3000/pro_carou/9_lg_5.jpg');

create table bs_detail_pic(
	id int(10) primary key auto_increment,
	pid varchar(10),
	pic varchar(150)
);
insert into bs_detail_pic values (null,1,'http://127.0.0.1:3000/pro_detail/1_detail_1.jpg');
insert into bs_detail_pic values (null,1,'http://127.0.0.1:3000/pro_detail/1_detail_2.jpg');
insert into bs_detail_pic values (null,1,'http://127.0.0.1:3000/pro_detail/1_detail_3.jpg');
insert into bs_detail_pic values (null,1,'http://127.0.0.1:3000/pro_detail/1_detail_4.jpg');
insert into bs_detail_pic values (null,1,'http://127.0.0.1:3000/pro_detail/1_detail_5.jpg');
insert into bs_detail_pic values (null,1,'http://127.0.0.1:3000/pro_detail/1_detail_6.jpg');
insert into bs_detail_pic values (null,1,'http://127.0.0.1:3000/pro_detail/1_detail_7.jpg');
insert into bs_detail_pic values (null,1,'http://127.0.0.1:3000/pro_detail/1_detail_8.jpg');
insert into bs_detail_pic values (null,1,'http://127.0.0.1:3000/pro_detail/1_detail_9.jpg');
insert into bs_detail_pic values (null,1,'http://127.0.0.1:3000/pro_detail/1_detail_10.jpg');
insert into bs_detail_pic values (null,6,'http://127.0.0.1:3000/pro_detail/6_detail_1.jpg');
insert into bs_detail_pic values (null,6,'http://127.0.0.1:3000/pro_detail/6_detail_2.jpg');
insert into bs_detail_pic values (null,6,'http://127.0.0.1:3000/pro_detail/6_detail_3.jpg');
insert into bs_detail_pic values (null,6,'http://127.0.0.1:3000/pro_detail/6_detail_4.jpg');
insert into bs_detail_pic values (null,6,'http://127.0.0.1:3000/pro_detail/6_detail_5.jpg');
insert into bs_detail_pic values (null,6,'http://127.0.0.1:3000/pro_detail/6_detail_6.jpg');
insert into bs_detail_pic values (null,6,'http://127.0.0.1:3000/pro_detail/6_detail_7.jpg');
insert into bs_detail_pic values (null,6,'http://127.0.0.1:3000/pro_detail/6_detail_8.jpg');
insert into bs_detail_pic values (null,6,'http://127.0.0.1:3000/pro_detail/6_detail_9.jpg');
insert into bs_detail_pic values (null,6,'http://127.0.0.1:3000/pro_detail/6_detail_10.jpg');
insert into bs_detail_pic values (null,6,'http://127.0.0.1:3000/pro_detail/6_detail_11.jpg');
insert into bs_detail_pic values (null,6,'http://127.0.0.1:3000/pro_detail/6_detail_12.jpg');
insert into bs_detail_pic values (null,6,'http://127.0.0.1:3000/pro_detail/6_detail_13.jpg');
insert into bs_detail_pic values (null,6,'http://127.0.0.1:3000/pro_detail/6_detail_14.jpg');
insert into bs_detail_pic values (null,8,'http://127.0.0.1:3000/pro_detail/8_detail_1.jpg');
insert into bs_detail_pic values (null,8,'http://127.0.0.1:3000/pro_detail/8_detail_2.jpg');
insert into bs_detail_pic values (null,8,'http://127.0.0.1:3000/pro_detail/8_detail_3.jpg');
insert into bs_detail_pic values (null,8,'http://127.0.0.1:3000/pro_detail/8_detail_4.jpg');
insert into bs_detail_pic values (null,8,'http://127.0.0.1:3000/pro_detail/8_detail_5.jpg');
insert into bs_detail_pic values (null,8,'http://127.0.0.1:3000/pro_detail/8_detail_6.jpg');
insert into bs_detail_pic values (null,8,'http://127.0.0.1:3000/pro_detail/8_detail_7.jpg');
insert into bs_detail_pic values (null,8,'http://127.0.0.1:3000/pro_detail/8_detail_8.jpg');
insert into bs_detail_pic values (null,8,'http://127.0.0.1:3000/pro_detail/8_detail_9.jpg');
insert into bs_detail_pic values (null,8,'http://127.0.0.1:3000/pro_detail/8_detail_10.jpg');
insert into bs_detail_pic values (null,8,'http://127.0.0.1:3000/pro_detail/8_detail_11.jpg');
insert into bs_detail_pic values (null,8,'http://127.0.0.1:3000/pro_detail/8_detail_12.jpg');
insert into bs_detail_pic values (null,9,'http://127.0.0.1:3000/pro_detail/9_detail_1.jpg');
insert into bs_detail_pic values (null,9,'http://127.0.0.1:3000/pro_detail/9_detail_2.jpg');
insert into bs_detail_pic values (null,9,'http://127.0.0.1:3000/pro_detail/9_detail_3.jpg');
insert into bs_detail_pic values (null,9,'http://127.0.0.1:3000/pro_detail/9_detail_4.jpg');
insert into bs_detail_pic values (null,9,'http://127.0.0.1:3000/pro_detail/9_detail_5.jpg');
insert into bs_detail_pic values (null,9,'http://127.0.0.1:3000/pro_detail/9_detail_6.jpg');
insert into bs_detail_pic values (null,9,'http://127.0.0.1:3000/pro_detail/9_detail_7.jpg');
insert into bs_detail_pic values (null,9,'http://127.0.0.1:3000/pro_detail/9_detail_8.jpg');
insert into bs_detail_pic values (null,9,'http://127.0.0.1:3000/pro_detail/9_detail_9.jpg');
insert into bs_detail_pic values (null,9,'http://127.0.0.1:3000/pro_detail/9_detail_10.jpg');
insert into bs_detail_pic values (null,9,'http://127.0.0.1:3000/pro_detail/9_detail_11.jpg');
insert into bs_detail_pic values (null,9,'http://127.0.0.1:3000/pro_detail/9_detail_12.jpg');
insert into bs_detail_pic values (null,9,'http://127.0.0.1:3000/pro_detail/9_detail_13.jpg');
insert into bs_detail_pic values (null,9,'http://127.0.0.1:3000/pro_detail/9_detail_14.jpg');
insert into bs_detail_pic values (null,9,'http://127.0.0.1:3000/pro_detail/9_detail_15.jpg');
insert into bs_detail_pic values (null,9,'http://127.0.0.1:3000/pro_detail/9_detail_16.jpg');


















