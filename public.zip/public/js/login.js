$(function(){
	var $btn=$(".button_style_l22");
		// console.log($btn);
		
	 $btn.on("click",function(){
		// console.log(123)
		var $uname=$(".user_style_l19 input").val();
		var $upwd=$(".upwd_style_l20 input").val();
		 //console.log($uname,$upwd);
		
		 $.ajax({
		url:'http://127.0.0.1:3000/login',
		type:'get',
		dataType:'json',
		data:{uname:$uname,upwd:$upwd},
		success:function(res){
			if(res.code==200){
				alert("登录成功，跳转至首页中...")
				 location.href="http://127.0.0.1/WEb.1812.PANTAO/04_HTML_CSS/DAY15/boot/PROJECT-01/public/HTML/index.html";
			}else{
				alert(res.msg)
			}
		}
	})
	})
})

var txtname=document.getElementsByName("uname")[0];
		var txtpwd=document.getElementsByName("upwd")[0];
		console.log(txtname,txtpwd)
		txtname.onfocus=txtpwd.onfocus=function getFocus(){
			this.className="txt_focus";
			var p=this.parentNode.nextElementSibling.firstElementChild;
			// console.log(p);
			p.className="";
		}
		
		txtname.onblur=function vali(){
			var reg=/^\w{6,10}$/;
			this.className="";
			var p=this.parentNode.nextElementSibling.firstElementChild;
			
			if(reg.test(this.value)){
				p.className="vali_success";
				return true;
			}else{
				p.className="vali_fail";
				return false;
			}	
		}
		txtpwd.onblur=function (){
			var reg=/^\d{6}$/;
			this.className="";
			var p=this.parentNode.nextElementSibling.firstElementChild;
			if(reg.test(this.value)){
				p.className="vali_success";
			}else{
				p.className="vali_fail";
			}
		}