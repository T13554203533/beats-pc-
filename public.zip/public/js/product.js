$(function(){
  // 绑定分页按钮，获得其内容，加一减去一赋值给上一页和下一页的href链接后面page
  // var $pul=$('.ul_style_p19');
  // $pul.on('click',"li.li_width_p18",function(){
  //   console.log(this)
  //     var $i=$(this).html();
  //     console.log($i+'abc')
  //     if($i>1&&$i<4)
  //     var $up="http://127.0.0.1/WEb.1812.PANTAO/04_HTML_CSS/DAY15/boot/PROJECT-01/public/HTML/product.html?page="+($i-1);
  //     var $down='http://127.0.0.1/WEb.1812.PANTAO/04_HTML_CSS/DAY15/boot/PROJECT-01/public/HTML/product.html?page='+($i+1);
  //     $pul.children(":last").attr('href',$down);
  //     $pul.children(":first").attr('href',$down);
  //   })
  
  
  // 获得页码按钮，此时url的查询字符串中的page，发送个服务器查询对应limit分页查询数据
  var page=location.search.slice(1).split('=')[1];
  $.ajax({
    url:'http://127.0.0.1:3000/product',
    data:{page},
    type:'get',
    dataType:"json",
    success:function(list){
      // 解构对象
       var {plist,recom}=list;
      var html='';
      // 循环动态生成商品列表
      for(var pro of plist){
        html+=`	<div class="product_style_p12">
        <a href="${pro.href}">
        <img class="img_scale_p17" src="${pro.pic}" alt="">
        </a>
        <p class="border_p15">
          <a class="a_style_p14 font_size_p02 font_size_p05" href="${pro.href}">￥${pro.price}.00</a>
        </p>
        <p class="border_p16">
          <a id="a_under_p1" class="font_size_p01 font_size_p06" href="${pro.href}">${pro.title}</a>
        </p>
        <p class="border_p17">
        <span class="font_size_p06 font_size_p07">总销量：
          <a class="a_style_p14 font_size_p03 font_size_p06" href="${pro.href}">${pro.sale}</a>
        </span> 
        <span class="font_size_p04 font_size_p06">评价：
          <a class="a_style_p14 font_size_p04 font_size_p06" href="${pro.href}">${pro.evaluate}</a>
        </span>
        </p>
      </div> `
      
        var divpro=$("#product_list");
        divpro.html(html);
      }
      // 生成商品推荐列表
      var html1="";
      for(var rec of recom){
        html1+=`<div class="product_style_p22">
        <a href="${rec.href}">
        <img class="img_scale_p17" src="${rec.pic}" alt="">
        </a>
        <p class="border_p15">
          <a class="a_style_p14 font_size_p02 font_size_p05" href="${rec.href}">￥${rec.price}</a>
        </p>
        <p class="border_p16">
          <a id="a_under_p1" class="font_size_p01 font_size_p06" href="${rec.href}">${rec.title}</a>
        </p>
        <p class="border_p17">
        <span class="font_size_p06 font_size_p07">总销量：
          <a class="a_style_p14 font_size_p03 font_size_p06" href="${rec.href}">${rec.sales}</a>
        </span> 
        
        </p>
      </div>`;
      var recom=$('#recom1');
      recom.html(html1);
      }
    }
  })
})
// 控制商品列表上面的表格隐藏与显示，按右上角的图片显示或者隐藏
var hide=document.querySelector('.table_style_p1 tr:first-child td img');
var trs=document.querySelectorAll('.table_style_p1 tr:not(:first-child)');
hide.onclick=function(){
    if(hide.className=="hide_button"){
      hide.className="";
      hide.src='../image/54(2).png'; 
      for(var tr of trs){
        if(tr.className!="tr_flex_p4 hide"){
          tr.className="hide";
        }   
      }
      trs[0].className="tr_flex_p4 hide";
    }else{
      hide.className="hide_button";
      hide.src='../image/54.png';
      for(var tr of trs){
        if(tr.className!="tr_flex_p4"){
          tr.className="";
        }
      }
      trs[0].className="tr_flex_p4";
    }

}