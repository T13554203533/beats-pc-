$(function(){
	var pid=location.search.slice(1).split('=')[1];
	//  console.log(pid)
	$.ajax({
		url:'http://127.0.0.1:3000/details',
		type:'get',
		data:{pid},
		dataType:'json',
		success:function(detail){
			var {title,color,introduce,picglass}=detail;
			// console.log(title);
			// console.log(color);
			// console.log(introduce);
			// console.log(picglass);
			// 放大镜图片
			var $picglass=$('#glass');
			// console.log($picglass);
			var html1='';
			for(var pic of picglass){
				// console.log(pic)
				html1+=`<li><img src="${pic.picsm}" 
				data-md="${pic.picmd}"
				data-lg="${pic.piclg}"
				alt=""> </li>`;
			}
			
			$picglass.html(html1);
			// 商品标题等信息
			var $title=$('div.div_pad_d6');
			var html3=`<h4 class="h3_style_d5">${title.title}</h4>
			<p class="style_color_d6">${title.subtitle}</p>
			<div class="price_style_p7">
				<span class="span_style_p9">价格</span>
				<span class="span_style_p10">￥${title.pirce}.00</span>
			</div>
			<p class="p_style_p11">运费<span class="span_style_p12">湖北武汉至 武汉江岸区大智街街道快递 0.00</span></p>
			<p class="p_style_d13">承诺：次日达 -18:00前付款</p>
			<ul class="ul_style_d14">
				<li>月销量<a href="">${title.salenum}</a></li>
				<li>累计评价<a href="">${title.evaluate}</a></li>
				<li>送天猫积分<a href="">${title.integral}</a></li>
			</ul>
			<div class="p_style_d15 pro_flex_44">
				<p class="color_title_45">颜色分类</p>
			
				<ul class="product_color_43">`;
			
			// 商品颜色
			// var $color=$('.product_color_43');
			// console.log($color);
			var html2='';
			for(var col of color){
				// console.log(col)
				html2+=`<li><img  src="${col.pcolor}" alt="">
				<p>${col.cname}</p>
			</li>`;
			}
			// $color.html(html2);
			html3+=html2;
			html3+=`	
			</ul>
		
		</div>
		<p class="p_style_d17">套餐类型<span class="span_style_d18">官方标配</span></p>
		
		<ul class="ul_style_p20 com">
				<li>数量</li>
				<li><button id="subtract">-</button></li>
				<li><input id="num_input" type="text" value="1" ></li>
				<li><button id="add">+</button></li>
				<li><span>库存5件</span></li>
			</ul>
	<div class="div_style_d21">
		<p class="com">服务</p>
		<select id="">
			<option value="">延保一年 ￥62.80</option>
			<option value="">延保二年 ￥73.80</option>
			<option value="">延保三年 ￥149.80</option>
		</select>
	</div>
	<div class="com div_style_d23">花呗分期<p class="p_style_d22"><img src="../image/81.png" alt=""><span>该商品最高可享6期分期免息</span></p></div>	
	<ul class="ul_style_d24">
		<li>
			<p>￥<span>${title.pricethree}</span>${title.threestages}</p>
			<p>(<span>0</span>手续费)</p>
		</li>
		<li>
			<p>￥<span>${title.pricesix}</span>${title.sixstages}</p>
			<p>(<span>0</span>手续费)</p>
		</li>
		<li>
			<p>￥<span>${title.pricetwelve}</span>${title.twelvestages}</p>
			<p>(含手续费)</p>
		</li>
	</ul>
	<div class="div_style_d27">
	<button class="button_buy_d25"><a href="">立即购买</a></button>
	<button class="btn_car_d26"><a href="">
	加入购物车</a>
	</button>
	</div>
	<div class="server_div_46">
	<ul class="ul_style_28">
		<li>服务承诺</li>
		<li><a href="">全国联保</a></li>
		<li><a href="">延保服务</a></li>
		<li><a href="">正品保障</a></li>
		<li><a href="">极速退款</a></li>
		<li><a href="">赠险运费</a></li>
		<li><a href="">七天无理由退换</a></li>
	</ul>
	</div>`;
			$title.html(html3);

			var $introduce=$('#detail_pic');
			// var html4=`<img class="img_mar_d40" src="${introduce[0].pic}" alt="">`;
			var html4="";
			for(var intro of introduce){
				html4+=`<img src="${intro.pic}" alt="">`;
			}
			$introduce.html(html4);

	// 商品加减按钮 
		var $btn=$(".ul_style_p20");
		var $inp=$btn.find("#num_input");
		var n=0;
		// console.log($inp);
		$btn.on("click","#subtract,#add",function(){
			if($(this).html()=="+"){
				n++;
				$inp.prop("value",n)
			}else{
				n--;
				if(n<1) n=1;
				$inp.prop("value",n)
				}
		})
//	1.图片加载
				var $ul=$(".lunbo_style ul");
//				console.log($ul);
				var $left=$(".lunbo_style>.left");
				var $right=$(".lunbo_style>.right");
//				console.log($left,$right);
				var $li=$(".lunbo_style ul>li");
				var $imgs=$(".lunbo_style ul>li img")
				var $mdimg=$(".div_border_d4>img");
//				console.log($mdimg);
				$ul.css('width',$li.length*96);
				if($li.length>=4){
					$left.addClass("disabled");
				}
				$mdimg.attr("src",`${picglass[0].picmd}`);
				var $lgimg=$(".img-lg");
				$lgimg.css("background-image",`url('${picglass[0].piclg}')`);
//2.小图片的左右移动
				var moved=0;
				$right.click(function(){
					if($right.is(":not(.disabled)")){
						moved++;
						$ul.css("margin-left",(-96)*moved);
						if(moved==$li.length-4){
							$right.addClass("disabled");
						}
						$left.removeClass("disabled");
					}
				})
				$left.click(function(){
					if($left.is(":not(.disabled)")){
						moved--;
						$ul.css("margin-left",-96*moved);
						if(moved==0){
							$left.addClass("disabled");
						}
						$right.removeClass("disabled");
					}
				})
//			3.鼠标进入每张小图片，更换中图片和大图片
				$ul.on("mouseenter","img",function(){
					var $img=$(this);

					var src=$img.attr("data-md");

					$mdimg.attr({src});

					var backgroundImage=`url(${$img.attr("data-lg")})`;

					$lgimg.css({backgroundImage});
				})


//			4.鼠标进入中图片，显示遮罩层并跟随鼠标移动

				var $mask=$(".mask");
				var $bmask=$(".big_mark");
//				$bmask.hover(function(){
//					$(".mask,.big_mark").toggleClass("d-none");
//				})
					$bmask.mouseenter(function(){
						$(".mask").removeClass("d-none");
						$lgimg.removeClass("d-none");
					})
					$bmask.mouseleave(function(){
						$(".mask").addClass("d-none");
						$lgimg.addClass("d-none");
					})
					$bmask.mousemove(function(e){
//						console.log(e.offsetX,e.offsetY)
						var left=e.offsetX-86;
						var top=e.offsetY-106;
						if(left<0) left=0;
						else if(left>214) left=214;
						if(top<0) top=0;
						else if(top>214) top=214;
						$mask.css({top,left})
						$lgimg.css("background-position",`-${left*80/43}px -${top*80/43}px`)
					})

				}
			})
	})


var moved=0;
var distance=180;
var up=document.getElementById('up');
var down=document.getElementById('down');
var divw=document.getElementById('vertical_shuffling');
var divg=document.getElementById('vertical_shuffling1');
up.onclick=function(){
	moved++
	if(moved>divw.children.length-3){
		moved=0
	}
	divw.style.top=-(moved*distance)+"px";
}
down.onclick=function(){
	moved--;
	if(moved<0){
		moved=divw.children.length-3
	}
	divw.style.top=-(moved*distance)+"px";
}













