
$(function(){
	console.log(213)
var $btn=$(".btn_style_r2")
	$btn.on("click",function(){
		console.log(123)
		var $uname=$("#uname").val();
		 console.log($uname);
			var $upwd=$("p>#password").val();
			console.log($upwd)
			var $email=$("#email").val();
			console.log($email)
			var $phone=$("#phone").val();
			console.log($phone);
		
		$.ajax({
			url:'http://127.0.0.1:3000/register',
			type:'post',
			dataType:'json',
			data:{uname:$uname,upwd:$upwd,email:$email,phone:$phone},
			success:function(res){
				if(res.code==200){
						alert(res.msg+",正在跳转至登录页面...")
						$(this).prop("disabled",true)
						location.href="http://127.0.0.1/WEb.1812.PANTAO/04_HTML_CSS/DAY15/boot/PROJECT-01/public/HTML/login.html";
				}
				else{
						alert(res.msg)
				}
			}
		})
	})
})

var txtname=document.getElementsByName("uname")[0];
				var txtpwd=document.getElementsByName("upwd")[0];
				var txtpwdTwo=document.getElementsByName("upwd")[1];
				var txtemail=document.getElementsByName("email")[0];
				var phone=document.getElementsByName("phone")[0];
				// console.log(txtpwd,txtpwdTwo);
				txtname.onfocus=function getFocus(){
						this.className="txt_focus";
						var span=this.nextElementSibling;
						span.className="span_1";
				}
				txtpwd.onfocus=txtemail.onfocus=phone.onfocus=txtpwdTwo.onfocus=function getFocus(){
						this.className="txt_focus";
						var span=this.nextElementSibling;
						span.className="";
				}
				txtpwdTwo.onfocus=function getFocus(){
						this.className="txt_focus";
				}
				txtname.onblur=function vali(){
						this.className="";
						var reg=/^\w{6,10}$/;
						var span=this.nextElementSibling;
						if(reg.test(this.value)){
							span.className="vali_successname";
							return true;
						}else{
							span.className="vali_failname";
							return false;
						}
				}
					txtpwd.onblur=function (){
						var reg=/^\d{6}$/;
						vali.call(this,reg);
           }
				
				txtemail.onblur=function(){
					var reg=/[a-zA-Z\d]+([\w]|[-.]+)*@+([\w]|[-.])+[\w]{2,4}/;
					vali.call(this,reg);
				}
				phone.onblur=function(){
					var reg=/^\d{11}$/;
					vali.call(this,reg);
				}
				txtpwdTwo.onblur=function(){
					this.className="";
					var span=this.nextElementSibling;
					if(this.value!=""&&txtpwd.value===this.value){
					span.className="vali_success";
					}else{
					span.className="vali_fail";	
					}		
				}
				function vali(reg){
						this.className="";
						var span=this.nextElementSibling;
						if(reg.test(this.value)){
							span.className="vali_success";
							return true;
						}else{
							span.className="vali_fail";
							return false;
						}
				}
			
