$(function(){
	
	var $floors=$(".floor")
	var $navbar=$(".ul_navbar")
	// console.log($floors)
	// console.log($navbar)
	$(window).scroll(function(){
		if($(window).scrollTop()>=800){
			$navbar.show()	
				$floors.each(function(i,f){
					var $f=$(f);
					var offsetTop=$f.offset().top
					if(offsetTop-innerHeight/2<=$(window).scrollTop()){
							$navbar.children(`.item:eq(${i})`).addClass("hover").siblings().removeClass("hover")
					}
				})
		}else{
			$navbar.hide()
		}
	})
	$navbar.on("click",".item",function(){
		var i=$(this).index()
		var offsetTop=$($floors[i]).offset().top-100;
		$("html").stop(true).animate({
			scrollTop:offsetTop
		},500)
	})
	var $point=$('#point');
	$(window).scroll(function(){
		if($(window).scrollTop()>=1000){
			$point.show();
		}else{
			$point.hide();
		}
	})
	$point.on('click',function(){
		$('html').stop(true).animate({
			scrollTop:0
		},1000)
	})
	$(window).trigger('scroll');
	$.ajax({
		url:'http://127.0.0.1:3000/index',
		type:'get',
		dataType:'json',
		success:function(res){
			// console.log(res);
			var {carousel,floor}=res;
			var $img1=$("#img1");
			$img1.attr("src",floor[0].pic);
			var $img2=$("#img2");
			$img2.attr("src",floor[1].pic);
			var $img3=$("#img3");
			$img3.attr("src",floor[2].pic);
			var $img4=$("#img4");
			$img4.attr("src",floor[3].pic);
			var $img5=$("#img5");
			$img5.attr("src",floor[4].pic);
			var $carou1=$("#carou1");
			var $carou2=$("#carou2");
			var $carou3=$("#carou3");
			$carou1.attr("src",carousel[0].pic);
			$carou2.attr("src",carousel[1].pic);
			$carou3.attr("src",carousel[2].pic);
		}
	})

})


var moved=0;
	var imgWidth=991;
	var ul=document.getElementsByClassName("banner_3")[0];
//	var ul=document.getElementsByClassName("banner_3")[0];
	var div=document.getElementsByClassName("banner_index_2")[0];
//		var div=document.getElementsByClassName("banner_index_2")[0];
	var left=document.getElementsByClassName("arrow_style_7")[0];
	var right=document.getElementsByClassName("arrow_style_7")[1];
	var ulButton=document.getElementsByClassName("banner_indicate_8")[0];
	
	function task(){
		moved--;
		if(moved<-(ul.children.length-1)){
			moved=0;
		}
		ul.style.left=moved*imgWidth+"px";
		button();
	}
	var timer=setInterval(task,2000);
	div.onmouseover=function(){
		clearInterval(timer);
		timer=null;
	}
	div.onmouseout=function(){
		timer=setInterval(task,2000);
	}
	left.onclick=function(){
		task();
	}
	right.onclick=function(){
		moved++;
		if(moved>0){
			moved=-(ul.children.length-1);
		}
		ul.style.left=moved*imgWidth+"px";
		button();
	}

	function button(){
		var index=Math.abs(moved);
		for(var i=0;i<ulButton.children.length;i++){
			if(ulButton.children[i].className==="banner_active_9"){
				ulButton.children[i].className="";
			}
			ulButton.children[index].className="banner_active_9";
		}
		for(var a=0;a<ulButton.children.length;a++){
			ulButton.children[a].onclick=function(){
				for(var b=0;b<ulButton.children.length;b++){
					ulButton.children[b].className="";
				}
				this.className="banner_active_9";
				var num=parseInt(this.getAttribute("count"));
				ul.style.left=-(num*imgWidth)+"px";
			}
		}

	}
