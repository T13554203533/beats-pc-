$(function(){
	$.ajax({
		url:"http://127.0.0.1/WEb.1812.PANTAO/04_HTML_CSS/DAY15/boot/PROJECT-01/public/HTML/footer.html",
		type:"get",
			success:function(res){
			$(res).replaceAll("footer")
			$(`<link rel="stylesheet" href="../CSS/footer.css">`).appendTo("head")
		}
	})
	
})