const express=require('express');
const pool=require('../pool.js');
var router=express.Router();
  router.post('/',(req,res)=>{
    var obj=req.body;
     console.log(obj)
    if(obj.uname==""){
      res.send({code:401,msg:'用户名不能为空'})
      return;
    }
    
    if(obj.upwd==""){
      res.send({code:402,msg:'密码不能为空'})
      return;
    }
    if(obj.email==''){
      res.send({code:403,msg:'邮箱不能为空'})
      return;
    }
    
    if(obj.phone==''){
      res.send({code:404,msg:'电话号码不能为空'})
      return;
    }
    
      var sql1="select uname from bs_user where uname=?";
      var sql2="select email from bs_user where email=?";
      var sql3='select phone from bs_user where phone=?';
      var sql="insert into bs_user set ?";
    pool.query(sql1,[obj.uname],(err,result)=>{
        if(err) throw err;
        if(result.length>0){
            res.send({code:405,msg:'用户名已存在'})
            // return;
        }else{
          pool.query(sql2,[obj.email],(err,result)=>{
            if(err) throw err;
            if(result.length>0){
              res.send({code:406,msg:'邮箱已被注册'})
              // return;
            }else{
              pool.query(sql3,[obj.phone],(err,result)=>{
                if(err) throw err;
                if(result.length>0){
                  res.send({code:407,msg:'手机号已被注册'})
                  // return
                }else{
                  pool.query(sql,[obj],(err,result)=>{
                    if(err) throw err;
                    if(result.affectedRows>0){
                      res.send({code:200,msg:'注册成功'})
                    }else{
                      res.send({code:201,msg:'注册失败'})
                    }
                  })

                }
              })

            }
          })
        }
      })
    
    // pool.query(sql2,[obj.email],(err,result)=>{
    //   if(err) throw err;
    //   if(result.length>0){
    //     res.send({code:406,msg:'邮箱已被注册'})
    //     // return;
    //   }
    // })
    
    // pool.query(sql3,[obj.phone],(err,result)=>{
    //   if(err) throw err;
    //   if(result.length>0){
    //     res.send({code:407,msg:'手机号已被注册'})
    //     // return
    //   }
    // })
    
    
    // pool.query(sql,[obj],(err,result)=>{
    //   if(err) throw err;
    //   if(result.affectedRows>0){
    //     res.send({code:200,msg:'注册成功'})
    //   }else{
    //     res.send({code:201,msg:'注册失败'})
    //   }
    // })

  })
module.exports=router;