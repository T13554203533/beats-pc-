const express=require('express');
const pool=require('../pool.js');

var router=express.Router();

router.get('/',(req,res)=>{
    var pid=req.query.pid;
    var detail={
        title:[],
        color:[],
        introduce:[],
        picglass:[]
    };
    var sql1='select * from bs_product_detail where pid = ?';
    if(pid!==undefined){
    pool.query(sql1,[pid],(err,result)=>{
        if(err) throw err;
        detail.title=result[0];
        var sql2='select * from bs_detail_color where pid = ?';
        pool.query(sql2,[pid],(err,result)=>{
            if(err) throw err;
            for(var i=0;i<result.length;i++){
                detail.color.push(result[i]);     
            }
            console.log(detail.color)
            // detail.color=result[0];
           var sql3 ='select * from bs_detail_pic where pid = ?';
           pool.query(sql3,[pid],(err,result)=>{
               if(err) throw err;
               console.log(result)
               for(var i=0;i<result.length;i++){
                   detail.introduce.push(result[i]);     
               }
            //    detail.introduce=result[0];
               console.log(detail.introduce);
               var sql4='select * from bs_detail_carousel where pid =?';
               pool.query(sql4,[pid],(err,result)=>{
                   if(err) throw err;
                   console.log(result);
                //    detail.picglass=result[0];
                for(var i=0;i<result.length;i++){
                    detail.picglass.push(result[i]);
                }
                   res.send(detail);
                   
               })
           }) 
        })
    })
}else{
    res.send(detail);
}
})
module.exports=router;
