const express=require('express');
const pool=require('../pool.js');
var router=express.Router();
//登录路由
router.get('/',(req,res)=>{
	var obj=req.query;
	if(obj.uname==""){
		res.send({code:401,msg:'用户名不能为空'})
			return;
	}
	if(obj.upwd==""){
		res.send({code:402,msg:"密码不能为空"})
			return;
	}
	var sql="select uname from bs_user where uname=? and upwd=?";
	
 pool.query(sql,[obj.uname,obj.upwd],(err,result)=>{
	 if(err) throw err;
	 console.log(result);
	 if(result.length>0){
			 res.send({code:200,msg:'登录成功'})
	 }else{
			res.send({code:201,msg:'用户名或密码有误'})
	 }
 })
})
 module.exports=router;