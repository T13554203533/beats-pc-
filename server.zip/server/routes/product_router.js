const express=require('express');
const pool=require('../pool.js');
var router=express.Router();
router.get("/",(req,res)=>{
  var page=req.query.page;
  console.log(page)
  var pagesize=30;
  var list={
    plist:[],
    recom:[]
  };
  if(page==undefined) page=1;
  var begin=(page-1)*pagesize;
  var sql='select * from bs_product_list limit ?,?';
  pool.query(sql,[begin,pagesize],(err,result)=>{
    if(err) throw err;
    for(var i=0;i<result.length;i++){
      list.plist.push(result[i]);
    }
    var sql1='select * from bs_product_recommend';
    pool.query(sql1,(err,result)=>{
      if(err) throw err;
      for(var i=0;i<result.length;i++){
        list.recom.push(result[i]);
      }
      res.send(list)
    })
  })

})
module.exports=router;