const express=require('express');
const pool=require('../pool.js');
var router=express.Router();
router.get('/',(req,res)=>{
  var index={
    floor:[],
    carousel:[]
  }
  var sql='select * from bs_index_product';
  pool.query(sql,[],(err,result)=>{
    if(err) throw err;
    index.floor=result;
    var sql1="select * from bs_product_carousel";
    pool.query(sql1,(err,result)=>{
      if(err) throw err;
      index.carousel=result;
      res.send(index);
    })
  })
})
module.exports=router;