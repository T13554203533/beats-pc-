const express=require('express');
const bodyParser=require('body-parser');
const cors=require('cors');
const login=require('./routes/login_router.js');
const register=require('./routes/register_router');
const index=require('./routes/index_router');
const details=require('./routes/detail_router');
const product=require('./routes/product_router');

var app=express();
//监听3000端口
var server=app.listen(3000);
app.use(express.static('./public'));
app.use(cors({
	"origin":"*",
	credentials:true
}));

app.use(bodyParser.urlencoded({extended:false}));

app.use("/login",login);
app.use('/register',register);
app.use('/index',index);
app.use('/product',product);
app.use('/details',details);













